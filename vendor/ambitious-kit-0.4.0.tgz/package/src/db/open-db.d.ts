import { DatabaseSync } from "node:sqlite";
export type Db = DatabaseSync;
export type OpenOptions = {
    readonly readonly: boolean;
};
export declare const readUserVersion: (db: Db) => number;
export declare const openDb: (path: string, { readonly }: OpenOptions) => Db;
