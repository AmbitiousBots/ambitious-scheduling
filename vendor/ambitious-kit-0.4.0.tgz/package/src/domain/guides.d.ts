export type Guide = {
    readonly topic: string;
    readonly title: string;
    readonly text: string;
};
export declare const parseGuides: (value: unknown) => readonly Guide[];
export declare const guideFor: (guides: readonly Guide[], topic: string) => Guide;
