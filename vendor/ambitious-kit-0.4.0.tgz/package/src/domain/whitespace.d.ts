export type TextMatch = "exact" | "whitespace";
export declare const foldWhitespace: (text: string) => string;
export type Fingerprint = {
    readonly sha256: string;
    readonly whitespaceSha256: string;
};
export declare const matchOf: (given: Fingerprint, published: Fingerprint) => TextMatch | null;
