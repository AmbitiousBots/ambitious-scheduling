export type SkillAction = "create" | "unchanged" | "update" | "keep";
export type SkillDecision = {
    readonly name: string;
    readonly action: SkillAction;
    readonly storedVersion: string | null;
    readonly candidateVersion: string;
    readonly tellOwner: string | null;
};
export type SkillOffer = {
    readonly name: string;
    readonly stored: string | null;
    readonly candidate: string;
};
export type SkillRequest = {
    readonly name: string;
    readonly stored: string | null;
    readonly candidate: string | null;
};
export declare const templateVersionOf: (body: string) => string | null;
export declare const decideSkillWrite: ({ name, stored, candidate }: SkillOffer) => SkillDecision;
export declare const skillChange: ({ name, action, storedVersion, candidateVersion }: SkillDecision) => string | null;
export declare const withTemplateBodies: (requests: readonly SkillRequest[], bodies: ReadonlyMap<string, string>) => readonly SkillOffer[];
export declare const parseSkillOffers: (value: unknown) => readonly SkillRequest[];
