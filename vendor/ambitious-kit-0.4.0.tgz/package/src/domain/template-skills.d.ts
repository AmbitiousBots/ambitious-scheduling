export type TemplateSkill = {
    readonly name: string;
    readonly description: string;
    readonly body: string;
};
export declare const INSTALLER_PIN_TOKEN: string;
export declare const withInstallerPin: (skills: readonly TemplateSkill[], installerSha256: string) => readonly TemplateSkill[];
export declare const parseTemplateSkills: (value: unknown) => readonly TemplateSkill[];
