export type Migration = {
    readonly name: string;
    readonly sql: string;
};
export declare const checkedMigrations: (migrations: readonly Migration[]) => readonly Migration[];
export declare const pendingMigrations: (migrations: readonly Migration[], userVersion: number) => readonly Migration[];
