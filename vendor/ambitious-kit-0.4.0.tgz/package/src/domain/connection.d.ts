export declare const MONITORING_IDENTITY = "ambitiousbots.com/mcp/v1";
export declare const MONITORING_TOOLS: readonly ["server_info", "send_report", "send_feedback"];
export declare const IDENTITY_TOOL = "server_info";
export type ConnectorOffer = {
    readonly name: string;
    readonly tools: readonly string[] | null;
    readonly serverInfo: {
        readonly identity: string | null;
    } | null;
};
export type ConnectorFinding = {
    readonly name: string;
    readonly kind: "monitoring";
    readonly identity: "confirmed" | "not confirmed";
    readonly why: string;
} | {
    readonly name: string;
    readonly kind: "different";
    readonly identity: "mismatch" | null;
    readonly why: string;
} | {
    readonly name: string;
    readonly kind: "unidentified";
    readonly identity: null;
    readonly why: string;
};
export type ConnectionAnswer = {
    readonly monitoring: string | null;
    readonly identity: "confirmed" | "not confirmed" | null;
    readonly toolsRead: number;
    readonly toolsNotRead: readonly string[];
    readonly connectors: readonly ConnectorFinding[];
    readonly tellOwner: readonly string[];
};
export declare const identifyConnector: ({ name, tools, serverInfo }: ConnectorOffer) => ConnectorFinding;
export declare const identifyConnection: (offers: readonly ConnectorOffer[]) => ConnectionAnswer;
export declare const parseConnectorOffers: (value: unknown) => readonly ConnectorOffer[];
