export declare const REVIEW_PAGE_EVERY_DAYS = 7;
export type ReviewPageState = {
    readonly builtAt: string | null;
    readonly highPriority: readonly string[];
};
export type ReviewPageDue = {
    readonly due: boolean;
    readonly daysSinceBuilt: number | null;
    readonly why: string;
};
export declare const NO_REVIEW_PAGE: ReviewPageState;
export declare const parseReviewPageState: (value: unknown) => ReviewPageState;
export declare const reviewPageDue: (builtAt: string | null, now: Date) => ReviewPageDue;
export declare const parseHighPriority: (value: unknown) => readonly string[];
export declare const newHighPriority: (seen: readonly string[], current: readonly string[]) => readonly string[];
