export type Clock = {
    readonly now: () => Date;
};
export type Rng = {
    readonly next: () => number;
    readonly int: (boundExclusive: number) => number;
};
export declare const MAX_SEED = 4294967295;
export declare const fixedClock: (instant: Date) => Clock;
export declare const seededRng: (seed: number) => Rng;
export declare const parseNow: (text: string) => Date | null;
export declare const parseSeed: (text: string) => number | null;
