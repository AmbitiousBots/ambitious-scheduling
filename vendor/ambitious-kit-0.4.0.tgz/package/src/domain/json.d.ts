export type JsonValue = string | number | boolean | null | readonly JsonValue[] | JsonObject;
export type JsonObject = {
    readonly [key: string]: JsonValue;
};
export declare const isRecord: (value: unknown) => value is Readonly<Record<string, unknown>>;
