export type ContractResult = {
    readonly id: string;
    readonly title: string;
    readonly problems: readonly string[];
};
export declare const runContract: (binPath: string) => readonly ContractResult[];
