import { type InstructionsCatalogue, type PermissionChange } from "../domain/instructions.ts";
import { type LineMerge } from "../domain/merge-lines.ts";
import { type TextMatch } from "../domain/whitespace.ts";
export type InstructionsMerge = LineMerge & {
    readonly state: "merged" | "conflicts" | "unknown base";
    readonly base: {
        readonly version: number;
        readonly match: TextMatch | "version line";
    } | null;
    readonly published: {
        readonly version: number | null;
        readonly sha256: string;
    };
    readonly permissions: PermissionChange | null;
    readonly permissionsStatement: string;
};
export declare const mergeInstructions: (currentFile: string, publishedFile: string, publishedSha256: string, catalogue: InstructionsCatalogue) => InstructionsMerge;
