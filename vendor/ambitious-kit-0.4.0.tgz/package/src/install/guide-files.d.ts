import type { Guide } from "../domain/guides.ts";
export declare const guidesDirectory: (home: string) => string;
export declare const placeGuideFile: (home: string, { topic, text }: Guide) => string;
