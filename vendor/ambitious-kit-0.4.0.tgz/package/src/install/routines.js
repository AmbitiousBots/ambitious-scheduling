import { join } from "node:path";
import { failure } from "../domain/failure.js";
import { classifyRoutine, parseRoutineOffers, routineMessage, ROUTINES_HINT } from "../domain/routines.js";
import { fingerprintOf, textOfFile } from "./text-file.js";
export const proposedRoutineFile = (name) => `routines/${name}.md`;
export const proposedRoutinePath = (home, name) => join(home, "template", proposedRoutineFile(name));
const offersIn = (file) => {
    const text = textOfFile(file, "The routines file", ROUTINES_HINT);
    try {
        return parseRoutineOffers(JSON.parse(text));
    }
    catch (error) {
        if (error instanceof SyntaxError)
            throw failure("E_INPUT_SCHEMA", `The routines file ${file} could not be read as JSON: ${error.message}.`, ROUTINES_HINT);
        throw error;
    }
};
export const checkRoutines = (file, home, template) => {
    if (file === null)
        return { state: "not checked", routines: [], messages: [] };
    const mine = offersIn(file).map(({ name, schedule, prompt }) => ({ name, schedule, ...fingerprintOf(prompt) }));
    const routines = template.map((routine) => ({ ...classifyRoutine(routine, mine), proposed: proposedRoutinePath(home, routine.name) }));
    return { state: "checked", routines, messages: routines.flatMap((finding) => routineMessage(finding, finding.proposed) ?? []) };
};
