import { type ReviewPageDue } from "../domain/review-page.ts";
export type ReviewPageReport = ReviewPageDue & {
    readonly file: string;
    readonly everyDays: number;
    readonly builtAt: string | null;
    readonly recorded: boolean;
    readonly highPriority: readonly string[];
    readonly newHighPriority: readonly string[];
};
export type ReviewPageRequest = {
    readonly home: string;
    readonly now: Date;
    readonly built: boolean;
    readonly highPriority: readonly string[] | null;
};
export declare const reviewPageStatePath: (home: string) => string;
export declare const reviewPage: ({ home, now, built, highPriority }: ReviewPageRequest) => ReviewPageReport;
