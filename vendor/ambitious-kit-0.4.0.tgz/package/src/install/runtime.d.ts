import { type Download } from "./install.ts";
export type RunTool = (program: string, args: readonly string[]) => Promise<void>;
export type RuntimeRequest = {
    readonly module: string;
    readonly version: string;
    readonly home: string;
    readonly download: Download;
    readonly runTool: RunTool;
    readonly python?: string;
};
export type RuntimeAction = "installed" | "unchanged";
export type RuntimeOutcome = {
    readonly action: RuntimeAction;
    readonly lock: string;
    readonly lockSha256: string;
    readonly path: string;
};
export declare const RUNTIME_MARKER = "ambitious-runtime.json";
export declare const RUNTIME_LOCK = "requirements.txt";
export declare const runtimeLockAsset: (module: string, version: string) => string;
export declare const runtimeLockProblems: (text: string) => readonly string[];
export declare const systemTool: RunTool;
export declare const installRuntime: ({ module, version, home, download, runTool, python }: RuntimeRequest) => Promise<RuntimeOutcome>;
