import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { isRecord } from "../domain/json.js";
import { refuseAgentData } from "../paths/refuse-agent-data.js";
import { placeByRename, refuseNonRegularFile } from "./install.js";
const FILE_NAME = /^[a-z0-9][a-z0-9.-]*(?:\/[a-z0-9][a-z0-9.-]*)*$/;
export const parseTemplateFiles = (value) => {
    if (!isRecord(value))
        throw new Error("The embedded template files must be an object of file name to text.");
    return new Map(Object.entries(value).map(([name, text]) => {
        if (!FILE_NAME.test(name) || typeof text !== "string")
            throw new Error(`The embedded template file "${name}" needs a lower-case relative name and text content.`);
        return [name, text];
    }));
};
const textIfPresent = (path) => {
    try {
        return readFileSync(path, "utf8");
    }
    catch {
        return null;
    }
};
export const templateDirectory = (home) => join(home, "template");
export const fixturesDirectory = (home) => join(templateDirectory(home), "fixtures");
export const placeTemplateFiles = (home, files) => {
    const root = templateDirectory(refuseAgentData(home));
    for (const [name, text] of files) {
        const path = join(root, name);
        refuseNonRegularFile(path);
        if (textIfPresent(path) === text)
            continue;
        mkdirSync(dirname(path), { recursive: true });
        placeByRename(dirname(path), name.slice(name.lastIndexOf("/") + 1), (descriptor) => writeFileSync(descriptor, text));
    }
    return root;
};
