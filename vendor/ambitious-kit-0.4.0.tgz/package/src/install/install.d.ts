export type AssetKind = "mjs" | "pyz";
export type Download = (fileName: string) => Promise<Uint8Array>;
export type InstallRequest = {
    readonly module: string;
    readonly version: string;
    readonly kind: AssetKind;
    readonly home: string;
    readonly download: Download;
    readonly pinned?: string;
};
export type InstallAction = "installed" | "replaced" | "relinked" | "unchanged";
export type InstallOutcome = {
    readonly action: InstallAction;
    readonly asset: string;
    readonly path: string;
    readonly link: string;
    readonly sha256: string;
};
export declare const SUMS_FILE = "SHA256SUMS";
export declare const parseSums: (text: string) => ReadonlyMap<string, string>;
export declare const refuseNonRegularFile: (path: string) => void;
export declare const currentLink: (path: string) => string | null;
export declare const placeByRename: (directory: string, name: string, write: (descriptor: number) => void) => void;
export declare const pointLink: (bin: string, linkName: string, asset: string) => void;
export declare const install: ({ module, version, kind, home, download, pinned }: InstallRequest) => Promise<InstallOutcome>;
