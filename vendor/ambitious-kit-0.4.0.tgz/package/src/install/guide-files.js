import { join } from "node:path";
import { placeTemplateFiles, templateDirectory } from "./template-files.js";
const fileOf = (topic) => `guides/${topic}.md`;
export const guidesDirectory = (home) => join(templateDirectory(home), "guides");
export const placeGuideFile = (home, { topic, text }) => join(placeTemplateFiles(home, new Map([[fileOf(topic), text]])), fileOf(topic));
