import type { Download } from "./install.ts";
export type ReleaseAddress = {
    readonly release: string;
    readonly tag: string;
};
export type Fetchers = {
    readonly web: (url: string) => Promise<Uint8Array>;
    readonly gh: (args: readonly string[]) => Promise<Uint8Array>;
    readonly webLatestTag: (repository: string) => Promise<string>;
};
export declare const KIT_REPOSITORY = "AmbitiousBots/ambitious-kit";
export declare const INSTALLER_MODULE = "modules";
export declare const networkFetchers: Fetchers;
export declare const releaseDownload: ({ release, tag }: ReleaseAddress, mirror: string | null, fetchers?: Fetchers) => Download;
export declare const latestInstallerVersion: (mirror: string | null, fetchers?: Fetchers) => Promise<string | null>;
