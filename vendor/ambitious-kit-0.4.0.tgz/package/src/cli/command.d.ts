import type { Clock, Rng } from "../domain/clock.ts";
import type { JsonObject } from "../domain/json.ts";
import type { Db } from "../db/open-db.ts";
export type Access = "read" | "write" | "none";
export type CommandContext<Input> = {
    readonly input: Input;
    readonly clock: Clock;
    readonly rng: Rng;
    readonly env: Readonly<Record<string, string | undefined>>;
};
export type DbContext<Input> = CommandContext<Input> & {
    readonly db: Db;
};
export type Output = JsonObject | Promise<JsonObject>;
export type Runtime = Omit<CommandContext<never>, "input"> & {
    readonly openDb: () => Db;
};
export type Command = {
    readonly access: Access;
    readonly takesInput: boolean;
    readonly parse: (rawInput: unknown) => (runtime: Runtime) => Output;
};
type InputOf<Input> = {
    readonly input: (raw: unknown) => Input;
};
type NoInput = {
    readonly input?: undefined;
};
export declare const readCommand: {
    <Input>(spec: InputOf<Input> & {
        readonly run: (context: DbContext<Input>) => Output;
    }): Command;
    (spec: NoInput & {
        readonly run: (context: DbContext<undefined>) => Output;
    }): Command;
};
export declare const writeCommand: {
    <Input>(spec: InputOf<Input> & {
        readonly run: (context: DbContext<Input>) => Output;
    }): Command;
    (spec: NoInput & {
        readonly run: (context: DbContext<undefined>) => Output;
    }): Command;
};
export declare function pureCommand<Input>(spec: InputOf<Input> & {
    readonly run: (context: CommandContext<Input>) => Output;
}): Command;
export declare function pureCommand(spec: NoInput & {
    readonly run: (context: CommandContext<undefined>) => Output;
}): Command;
export {};
