const parsed = (spec, raw) => spec.input === undefined ? undefined : spec.input(raw);
const withDb = (access) => {
    function define(spec) {
        return {
            access,
            takesInput: spec.input !== undefined,
            parse: (rawInput) => {
                const input = parsed(spec, rawInput);
                return ({ openDb, ...context }) => spec.run({ ...context, input, db: openDb() });
            },
        };
    }
    return define;
};
export const readCommand = withDb("read");
export const writeCommand = withDb("write");
export function pureCommand(spec) {
    return {
        access: "none",
        takesInput: spec.input !== undefined,
        parse: (rawInput) => {
            const input = parsed(spec, rawInput);
            return ({ openDb: _openDb, ...context }) => spec.run({ ...context, input });
        },
    };
}
